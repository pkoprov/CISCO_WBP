.. _examples-index:

.. _gallery:

========
Examples
========

This page contains example plots. Click on any image to see the full image
and source code.

For longer tutorials, see our `tutorials page <../tutorials/index.html>`_.
You can also find `external resources <../users/resources/index.html>`_ and
a `FAQ <../users/faq/index.html>`_ in our `user guide <../users/index.html>`_.
