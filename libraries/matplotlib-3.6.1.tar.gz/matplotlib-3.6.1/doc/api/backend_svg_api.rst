:mod:`.backend_svg`
===================

.. automodule:: matplotlib.backends.backend_svg
   :members:
   :undoc-members:
   :show-inheritance:
