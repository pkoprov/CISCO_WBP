:mod:`.backend_wxagg`, :mod:`.backend_wxcairo`
==============================================

**NOTE** These backends are not documented here, to avoid adding a dependency
to building the docs.

.. redirect-from:: /api/backend_wxagg_api

.. module:: matplotlib.backends.backend_wxagg
.. module:: matplotlib.backends.backend_wxcairo
