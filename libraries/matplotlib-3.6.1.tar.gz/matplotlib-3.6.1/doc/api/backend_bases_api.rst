
:mod:`matplotlib.backend_bases`
================================

.. automodule:: matplotlib.backend_bases
   :members:
   :undoc-members:
   :show-inheritance:
