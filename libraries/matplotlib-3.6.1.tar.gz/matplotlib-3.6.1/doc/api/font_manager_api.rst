***************************
``matplotlib.font_manager``
***************************

.. automodule:: matplotlib.font_manager
   :members:
   :undoc-members:
   :show-inheritance:

    .. data:: fontManager

        The global instance of `FontManager`.

.. autoclass:: FontEntry
   :no-undoc-members:
