******************
``matplotlib.afm``
******************

.. attention::
    This module is considered internal.

    Its use is deprecated and it will be removed in a future version.

.. automodule:: matplotlib._afm
   :members:
   :undoc-members:
   :show-inheritance:
