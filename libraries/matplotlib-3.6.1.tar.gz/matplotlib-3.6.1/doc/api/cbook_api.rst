********************
``matplotlib.cbook``
********************

.. automodule:: matplotlib.cbook
   :members:
   :undoc-members:
   :show-inheritance:
