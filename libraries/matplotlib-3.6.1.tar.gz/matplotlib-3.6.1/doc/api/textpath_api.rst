***********************
``matplotlib.textpath``
***********************

.. automodule:: matplotlib.textpath
   :members:
   :undoc-members:
   :show-inheritance:
